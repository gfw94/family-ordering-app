# 极空间 Docker 部署步骤

这套方案用于在极空间上长期运行家庭点菜项目，并通过后续的 Cloudflare Tunnel 对外提供统一访问地址。

## 一、准备文件

把以下文件上传到极空间同一个目录，例如 `docker/family-ordering/`：

- `index.html`
- `app.js`
- `styles.css`
- `backend/server.py`
- `backend/schema.sql`
- `Dockerfile`
- `.dockerignore`
- `docker-compose.zspace.yml`

同时确保目录下存在 `data/` 子目录，用来保存 SQLite 数据库。

## 二、创建容器

如果极空间支持 Compose 或项目编排：

1. 在 Docker 应用中新建项目。
2. 选择 `docker-compose.zspace.yml`。
3. 工作目录指向当前项目目录。
4. 启动项目。

如果极空间只支持单容器：

1. 用 `Dockerfile` 构建镜像。
2. 新建容器，镜像选择构建后的 `family-ordering`。
3. 端口映射设置为 `8000:8000`。
4. 把极空间上的 `data` 目录挂载到容器内 `/data`。
5. 重启策略选择 `unless-stopped` 或等效的开机自启。

## 三、本地验证

启动后，先在极空间所在局域网内访问：

- `http://极空间局域网IP:8000`

确认以下几点：

1. 页面能打开。
2. 管理后台可以进入。
3. 打开管理后台时提示已检测到 SQLite 后端。
4. 保存共享配置后，`data/main.db` 会自动创建。

## 四、后续公网接入

本地验证通过后，再配置 Cloudflare Tunnel，把公网域名转发到：

- `http://极空间局域网IP:8000`

这样前端页面和 `/api/state` 会保持同源访问，不需要额外改代码。